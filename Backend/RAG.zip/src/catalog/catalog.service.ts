import { analyzeCatalog, CatalogAnalysis } from "./catalogAnalyzer";
import {
  getHeaders,
  getProducts,
} from "../services/googleSheets.service";

let catalogMetadata: CatalogAnalysis | null = null;

export async function initializeCatalog(): Promise<void> {
  try {
    console.log("\n==============================");
    console.log("Loading Product Catalog...");
    console.log("==============================");

    const headers = await getHeaders();
    const products = await getProducts();

    if (products.length === 0) {
      throw new Error("No products found in Google Sheet.");
    }

    const normalizedHeaders = headers
      .map(h => h.trim())
      .filter(Boolean);

    const sampleProducts = products.slice(0, 5);

    try {
      const aiMetadata = await analyzeCatalog(
        normalizedHeaders,
        sampleProducts
      );

      catalogMetadata = {
        catalogType:
          aiMetadata.catalogType || "Unknown",

        importantFields: Array.from(
          new Set([
            ...normalizedHeaders,
            ...(aiMetadata.importantFields ?? [])
          ])
        ),

        searchFields: Array.from(
          new Set([
            ...normalizedHeaders,
            ...(aiMetadata.searchFields ?? [])
          ])
        ),

        comparisonFields: Array.from(
          new Set([
            ...normalizedHeaders,
            ...(aiMetadata.comparisonFields ?? [])
          ])
        ),

        recommendedQuestions:
          aiMetadata.recommendedQuestions ?? []
      };

    } catch {

      console.log(
        "AI Catalog Analysis unavailable. Using Google Sheet headers."
      );

      catalogMetadata = {
        catalogType: "Unknown",

        importantFields: normalizedHeaders,

        searchFields: normalizedHeaders,

        comparisonFields: normalizedHeaders,

        recommendedQuestions: [],
      };
    }

    console.log("\n========== CATALOG ==========");
    console.log(JSON.stringify(catalogMetadata, null, 2));
    console.log("=============================\n");

  } catch (error) {

    console.error("Failed to initialize catalog.");
    console.error(error);

    throw error;
  }
}

export function getCatalogMetadata(): CatalogAnalysis {

  if (!catalogMetadata) {
    throw new Error(
      "Catalog has not been initialized."
    );
  }

  return catalogMetadata;
}

export function isCatalogLoaded(): boolean {
  return catalogMetadata !== null;
}
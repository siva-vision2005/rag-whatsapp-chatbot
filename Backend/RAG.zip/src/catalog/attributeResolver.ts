import { resolveFieldValue } from "../search/smartFieldResolver";

const ATTRIBUTE_ALIASES: Record<string, string[]> = {
  brand: [
    "Brand",
    "Manufacturer",
    "Company",
    "Make"
  ],

  price: [
    "Price",
    "Selling Price",
    "MRP",
    "Cost"
  ],

  category: [
    "Type",
    "Product Type",
    "Category",
    "Product Category",
    "Suitable For"
  ],

  product_type: [
    "Type",
    "Product Type",
    "Category",
    "Product Category",
    "Suitable For"
  ],

  processor: [
    "Processor",
    "Processor Name",
    "CPU"
  ],

  ram: [
    "RAM",
    "Memory",
    "System Memory"
  ],

  storage: [
    "Storage",
    "SSD",
    "SSD Capacity",
    "HDD"
  ],

  gpu: [
    "GPU",
    "Graphics",
    "Graphic Processor",
    "Dedicated Graphic Memory Type",
    "Dedicated Graphic Memory Capacity"
  ],

  purpose: [
    "Suitable For",
    "Purpose",
    "Usage"
  ]
};

export function resolveAttribute(
  payload: Record<string, any>,
  attribute: string
): any {

  const aliases =
  ATTRIBUTE_ALIASES[attribute.toLowerCase()] ?? [attribute];

  for (const alias of aliases) {

    const value = resolveFieldValue(
      payload,
      alias
    );

    if (
      value !== undefined &&
      value !== null &&
      value !== ""
    ) {
      return value;
    }

  }

  return undefined;

}
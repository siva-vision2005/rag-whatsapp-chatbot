import { aiService } from "../services/ai.service";
import { buildCatalogPrompt } from "../prompts/catalog.prompt";

export interface CatalogAnalysis {
  catalogType: string;

  importantFields: string[];

  searchFields: string[];

  comparisonFields: string[];

  recommendedQuestions: {
    field: string;
    question: string;
  }[];
}

export async function analyzeCatalog(
  headers: string[],
  sampleProducts: Record<string, any>[]
): Promise<CatalogAnalysis> {
  try {
    const prompt = buildCatalogPrompt(
      headers,
      sampleProducts
    );

    const result =
      await aiService.generateJson<CatalogAnalysis>(
        prompt,
        "gemini-2.5-flash"
      );

    return result;
  } catch (error) {
    console.error("Catalog Analyzer Error");
    console.error(error);

    return {
      catalogType: "Unknown",
      importantFields: [],
      searchFields: [],
      comparisonFields: [],
      recommendedQuestions: [],
    };
  }
}
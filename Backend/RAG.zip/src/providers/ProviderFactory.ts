import { AIProvider } from "./AIProvider";
import { GeminiProvider } from "./GeminiProvider";
import { GroqProvider } from "./GroqProvider";

export class ProviderFactory {
  static getProvider(providerName?: string): AIProvider {
    const provider = (
      providerName ??
      process.env.AI_PROVIDER ??
      "gemini"
    ).toLowerCase();

    switch (provider) {
      case "gemini":
        console.log("✨ Using Gemini Provider");
        return new GeminiProvider();

      case "groq":
        console.log("🚀 Using Groq Provider");
        return new GroqProvider();

      default:
        console.warn(
          `⚠ Unknown provider "${provider}". Falling back to Gemini.`
        );
        return new GeminiProvider();
    }
  }
}
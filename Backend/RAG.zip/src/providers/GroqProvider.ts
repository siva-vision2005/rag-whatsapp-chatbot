import { AIProvider } from "./AIProvider";
import { groq } from "../config/groq";

const DEFAULT_GROQ_MODEL = "llama-3.3-70b-versatile";

export class GroqProvider implements AIProvider {

  private resolveModel(model?: string): string {

    if (
      !model ||
      model.startsWith("gemini")
    ) {
      return DEFAULT_GROQ_MODEL;
    }

    return model;
  }

  async generateText(
    prompt: string,
    model?: string
  ): Promise<string> {

    const response = await groq.chat.completions.create({

      model: this.resolveModel(model),

      messages: [
        {
          role: "user",
          content: prompt,
        },
      ],

    });

    return response.choices[0]?.message?.content ?? "";
  }

  async generateJson<T>(
    prompt: string,
    model?: string
  ): Promise<T> {

    const response = await groq.chat.completions.create({

      model: this.resolveModel(model),

      messages: [
        {
          role: "system",
          content:
            "Always return ONLY valid JSON. Never use markdown or code blocks.",
        },
        {
          role: "user",
          content: prompt,
        },
      ],

      response_format: {
        type: "json_object",
      },

    });

    const text =
      response.choices[0]?.message?.content ?? "{}";

    return JSON.parse(text) as T;
  }

  async embed(text: string): Promise<number[]> {

    throw new Error(
      "Groq does not support embeddings. Use Gemini for embeddings."
    );

  }
}
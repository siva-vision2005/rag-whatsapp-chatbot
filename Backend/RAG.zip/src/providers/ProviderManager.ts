import { AIProvider } from "./AIProvider";
import { ProviderFactory } from "./ProviderFactory";

export class ProviderManager {
  private provider: AIProvider;

  constructor() {
    this.provider = ProviderFactory.getProvider();
  }

  private shouldFallback(error: any): boolean {
    const status =
      error?.status ??
      error?.response?.status ??
      error?.code;

    return (
      process.env.AI_PROVIDER?.toLowerCase() === "gemini" &&
      [400, 401, 403, 429, 500, 502, 503, 504].includes(Number(status))
    );
  }

  async generateText(
    prompt: string,
    model?: string
  ): Promise<string> {
    try {
      return await this.provider.generateText(prompt, model);
    } catch (error: any) {
      if (!this.shouldFallback(error)) {
        throw error;
      }

      console.warn("Gemini unavailable. Falling back to Groq.");

      const fallbackProvider =
        ProviderFactory.getProvider("groq");

      return await fallbackProvider.generateText(prompt);
    }
  }

  async generateJson<T>(
    prompt: string,
    model?: string
  ): Promise<T> {
    try {
      return await this.provider.generateJson<T>(
        prompt,
        model
      );
    } catch (error: any) {
      if (!this.shouldFallback(error)) {
        throw error;
      }

      console.warn("Gemini unavailable. Falling back to Groq.");

      const fallbackProvider =
        ProviderFactory.getProvider("groq");

      return await fallbackProvider.generateJson<T>(
        prompt
      );
    }
  }

  async embed(text: string): Promise<number[]> {
    return await this.provider.embed(text);
  }
}
import { AIProvider } from "./AIProvider";
import { generateWithRetry } from "../utils/gemini.retry";
import { gemini } from "../config/gemini";

export class GeminiProvider implements AIProvider {

  async generateText(
    prompt: string,
    model = "gemini-2.5-flash"
  ): Promise<string> {

    const response = await generateWithRetry({
      model,
      prompt,
    });

    return response.text ?? "";
  }

  async generateJson<T>(
    prompt: string,
    model = "gemini-2.5-flash"
  ): Promise<T> {
    console.log("GeminiProvider model:", model);
    const response = await generateWithRetry({
      model,
      prompt,
      responseMimeType: "application/json",
    });

    const cleaned = (response.text ?? "{}")
      .replace(/```json/g, "")
      .replace(/```/g, "")
      .trim();

    return JSON.parse(cleaned) as T;
  }

  async embed(text: string): Promise<number[]> {

    const response = await gemini.models.embedContent({
      model: "gemini-embedding-001",
      contents: text,
    });

    const vector = response.embeddings?.[0]?.values;

    if (!vector) {
      throw new Error("Embedding generation failed.");
    }

    return vector;
  }
}
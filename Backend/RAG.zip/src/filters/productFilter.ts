import { resolveAttribute } from "../catalog/attributeResolver";
import { resolveFieldValue } from "../search/smartFieldResolver";
export interface SearchProduct {
  score: number;
  payload: Record<string, any>;
}

const FALLBACK_SEARCH_FIELDS = [
  "name",
  "title",
  "product",
  "product name",
  "model",
  "series",
  "description",
];

const EXACT_MATCH_FIELDS = [
  "model",
  "model number",
  "part number",
  "sku",
];

export function filterProducts(
  products: SearchProduct[],
  filters: Record<string, unknown>
): SearchProduct[] {

  if (products.length === 0) {
    return [];
  }

  return products.filter((product) => {

    const payload = product.payload;

    for (const [field, rawFilterValue] of Object.entries(filters)) {

      if (
        rawFilterValue === undefined ||
        rawFilterValue === null ||
        rawFilterValue === ""
      ) {
        continue;
      }

      const filterValue = String(rawFilterValue).trim();

      const normalizedField = normalize(field);

      

// ...

let payloadValue = resolveAttribute(payload, field)
console.log("Field:", field);
console.log("Filter:", filterValue);
console.log("Resolved:", payloadValue);
console.log("----------------------");
console.log("Resolved from resolver:", payloadValue);

      //------------------------------------
      // Exact Match Fields
      //------------------------------------

      if (
        EXACT_MATCH_FIELDS.includes(
          normalizedField
        )
      ) {

        if (
          payloadValue === undefined ||
          payloadValue === null
        ) {
          return false;
        }

        if (
          normalize(String(payloadValue)) !==
          normalize(filterValue)
        ) {
          return false;
        }

        continue;
      }

      //------------------------------------
      // Fallback Search
      //------------------------------------

      if (
        payloadValue === undefined ||
        payloadValue === null
      ) {

        const matched = searchFallbackFields(
          payload,
          filterValue
        );

        if (!matched) {
          return false;
        }

        continue;

      }

      //------------------------------------
      // Normal Comparison
      //------------------------------------

      const matched = compareValue(
  payloadValue,
  filterValue
);

console.log("\n========== FILTER DEBUG ==========");
console.log("Field:", field);
console.log("Expected:", filterValue);
console.log("Resolved Value:", payloadValue);
console.log("Matched:", matched);
console.log("==================================");

if (!matched) {
  return false;
}

    }

    return true;

  });

}

function findPayloadValue(
  payload: Record<string, any>,
  field: string
): any {

  const normalizedField = normalize(field);

  for (const [key, value] of Object.entries(payload)) {

    if (
      normalize(key) === normalizedField
    ) {
      return value;
    }

  }

  return undefined;

}

function searchFallbackFields(
  payload: Record<string, any>,
  searchValue: string
): boolean {

  const keyword = normalize(searchValue);

  for (const field of FALLBACK_SEARCH_FIELDS) {

    const value = resolveFieldValue(
  payload,
  field
);

    if (
      value !== undefined &&
      normalize(String(value)).includes(keyword)
    ) {
      return true;
    }

  }

  return false;

}

function compareValue(
  payloadValue: any,
  filterValue: string
): boolean {

  const payloadNumber = Number(
    String(payloadValue).replace(/[^\d.]/g, "")
  );

  //------------------------------------
  // <=
  //------------------------------------

  if (filterValue.startsWith("<=")) {

    const limit = Number(
      filterValue.substring(2)
    );

    if (!isNaN(limit)) {
      return payloadNumber <= limit;
    }

  }

  //------------------------------------
  // >=
  //------------------------------------

  if (filterValue.startsWith(">=")) {

    const limit = Number(
      filterValue.substring(2)
    );

    if (!isNaN(limit)) {
      return payloadNumber >= limit;
    }

  }

  //------------------------------------
  // <
  //------------------------------------

  if (filterValue.startsWith("<")) {

    const limit = Number(
      filterValue.substring(1)
    );

    if (!isNaN(limit)) {
      return payloadNumber < limit;
    }

  }

  //------------------------------------
  // >
  //------------------------------------

  if (filterValue.startsWith(">")) {

    const limit = Number(
      filterValue.substring(1)
    );

    if (!isNaN(limit)) {
      return payloadNumber > limit;
    }

  }

  //------------------------------------
  // Text Match
  //------------------------------------

  return normalize(
    String(payloadValue)
  ).includes(
    normalize(filterValue)
  );

}

function normalize(value: string): string {

  return value
    .toLowerCase()
    .replace(/\s+/g, "")      // Remove ALL spaces
    .replace(/-/g, "")        // Remove hyphens
    .trim();

}
import { filterProducts } from "../filters/productFilter";
import { formatSearchResponse } from "../formatter/responseFormatter";
import * as ProductRanker from "../ranking/productRanker";
import { buildSearchQuery } from "../search/searchQueryBuilder";
import { searchProducts } from "../search/searchProducts";

export interface ProductSearchResult {
  reply: string;
  products: Record<string, any>[];
}

const NON_FILTER_FIELDS = new Set([
  "name",
  "title",
  "product",
  "product name",
  "description",
]);

export async function handleProductSearch(
  customerMessage: string,
  conversationState: Record<string, any>
): Promise<ProductSearchResult> {

  //----------------------------------------
  // Build Semantic Search Query
  //----------------------------------------

  const searchQuery = buildSearchQuery(
    customerMessage,
    conversationState
  );

  console.log("\n========== PRODUCT SEARCH ==========");
  console.log("Search Query:");
  console.log(searchQuery);
  console.log("====================================\n");

  //----------------------------------------
  // Semantic Search
  //----------------------------------------

  //----------------------------------------
// Semantic Search
//----------------------------------------

const retrievedProducts = await searchProducts(
  searchQuery
);

// DEBUG: Print first payload
if (retrievedProducts.length > 0) {

  console.log("\n========== FIRST PAYLOAD ==========");

  const rtxLaptop = retrievedProducts.find(p =>
    (p.payload.name ?? "").toLowerCase().includes("rtx")
);

if (rtxLaptop) {

    console.log("\n========== RTX PAYLOAD ==========");
    console.log(
        JSON.stringify(rtxLaptop.payload, null, 2)
    );
    console.log("================================");

}console.log(
    JSON.stringify(
      retrievedProducts[0].payload,
      null,
      2
    )
  );

  console.log("===================================\n");

}

// Existing code
console.log("\n========== RETRIEVED PRODUCTS ==========");

retrievedProducts.forEach((p, index) => {

  console.log(
    index + 1,
    p.payload.Brand ??
    p.payload.brand ??
    p.payload.Manufacturer ??
    "Unknown",
    "-",
    p.payload.name ??
    p.payload.title
  );

});

console.log("========================================");
  console.log("\n========== RETRIEVED PRODUCTS ==========");

retrievedProducts.forEach((p, index) => {

    console.log(
        index + 1,
        p.payload.Brand ??
        p.payload.brand ??
        p.payload.Manufacturer ??
        "Unknown",
        "-",
        p.payload.name ??
        p.payload.title
    );

});

console.log("========================================");

  console.log(
    `Products Retrieved: ${retrievedProducts.length}`
  );

  //----------------------------------------
  // Build Safe Filters
  //----------------------------------------

  const safeFilters = buildSafeFilters(
    conversationState
  );
  console.log("\n========== CONVERSATION STATE ==========");
console.log(JSON.stringify(conversationState, null, 2));

console.log("\n========== SAFE FILTERS ==========");
console.log(JSON.stringify(safeFilters, null, 2));
console.log("========================================");

  console.log("\n========== SAFE FILTERS ==========");
  console.log(
    JSON.stringify(safeFilters, null, 2)
  );
  console.log("==================================\n");

  //----------------------------------------
  // Application Filtering
  //----------------------------------------

  const filteredProducts = filterProducts(
    retrievedProducts,
    safeFilters
  );
  console.log("\n========== FILTERED PRODUCTS ==========");

filteredProducts.forEach((p, index) => {

    console.log(
        index + 1,
        p.payload.Brand ??
        p.payload.brand ??
        p.payload.Manufacturer ??
        "Unknown",
        "-",
        p.payload.name ??
        p.payload.title
    );

});

console.log("=======================================");

  //----------------------------------------
  // Ranking
  //----------------------------------------

  const rankedProducts = ProductRanker.rankProducts(
    filteredProducts,
    conversationState
  );

  console.log("\n========== PRODUCT RANKING ==========");

  console.table(
    rankedProducts.map((item) => ({
      Score: item.score,
      Reasons: item.reasons.join(", "),
      Product:
        item.product.payload.name ??
        item.product.payload.title ??
        item.product.payload.product ??
        "Unknown",
    }))
  );

  console.log("=====================================\n");

  //----------------------------------------
  // Top Products
  //----------------------------------------

  const topProducts = rankedProducts
    .slice(0, 5)
    .map((item) => item.product);

  //----------------------------------------
  // Professional Formatter
  //----------------------------------------

  const reply = formatSearchResponse(
    topProducts.map((item) => item.payload)
  );

  return {
    reply,
    products: topProducts.map((item) => item.payload),
  };

}

function buildSafeFilters(
  conversationState: Record<string, any>
): Record<string, any> {

  const filters: Record<string, any> = {};

  for (const [key, value] of Object.entries(
    conversationState
  )) {

    if (
      value === undefined ||
      value === null ||
      value === ""
    ) {
      continue;
    }

    const normalizedKey = key
      .toLowerCase()
      .trim();

    if (
      NON_FILTER_FIELDS.has(normalizedKey)
    ) {
      continue;
    }

    filters[key] = value;

  }

  return filters;

}
import { aiService } from "../services/ai.service";
import { formatAIResponse } from "../formatter/aiResponseFormatter";

export async function handleGeneralKnowledge(
  message: string
): Promise<string> {
  try {
    const prompt = `
You are a professional AI Product Assistant for a company.

====================================================
CUSTOMER QUESTION
====================================================

${message}

====================================================
RULES
====================================================

1. Answer only using accurate, generally accepted knowledge.
2. Never invent company information.
3. Never invent product specifications.
4. Never mention AI models, prompts, embeddings, vector databases, or internal systems.
5. Keep the answer concise and easy to understand.
6. If the customer asks about products, answer only if product information is available.
7. If appropriate, suggest asking for product recommendations.

====================================================
FORMAT
====================================================

Return plain text only.

Never use Markdown.

Do NOT use:
*
**
#
|
\`

Use short paragraphs.

Use bullet points (•) where appropriate.

Maximum 6 bullet points.

Avoid repeating information.

Use WhatsApp-friendly formatting.

End naturally without unnecessary text.
`;

    const response = await aiService.generateText(prompt);

return formatAIResponse(response);
  } catch (error) {
    console.error("General Knowledge Handler Error");
    console.error(error);

    return "Sorry, I'm unable to answer that question right now. Please try again later.";
  }
}
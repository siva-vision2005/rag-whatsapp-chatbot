import { aiService } from "../services/ai.service";
import { buildProductComparisonPrompt } from "../prompts/productComparison.prompt";
import { formatAIResponse } from "../formatter/aiResponseFormatter";
import { resolveComparisonProducts } from "../services/comparisonResolver";

export async function handleProductComparison(
  entities: Record<string, any>,
  lastProducts: Record<string, any>[]
): Promise<string> {

  try {

    const selectedProducts = await resolveComparisonProducts(
      entities,
      lastProducts
    );

    if (selectedProducts.length < 2) {
      return "⚠️ I couldn't identify two products to compare. Please specify two product names or search for products first.";
    }

    const customerMessage =
      entities.comparison_products?.join(" vs ") ??
      entities.comparison_numbers?.join(" vs ") ??
      "Compare these products";

    const prompt = buildProductComparisonPrompt(
      customerMessage,
      selectedProducts
    );

    const response = await aiService.generateText(prompt);

    return formatAIResponse(response);

  } catch (error) {

    console.error("Product Comparison Handler Error");
    console.error(error);

    return "❌ Sorry, I couldn't compare those products at the moment. Please try again.";
  }
}
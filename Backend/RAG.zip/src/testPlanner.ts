import { PlannerService } from "./ai/planner/planner.service";

async function test() {
  const planner = new PlannerService();

  const result = await planner.plan(
    "Show me Dell gaming laptops under 60000"
  );

  console.log(JSON.stringify(result, null, 2));
}

test().catch(console.error);
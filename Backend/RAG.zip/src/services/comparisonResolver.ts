import { resolveProduct } from "./productResolver";

export async function resolveComparisonProducts(
  entities: Record<string, any>,
  lastProducts: Record<string, any>[]
): Promise<Record<string, any>[]> {

  // Compare by product names
  if (entities.comparison_products) {

    console.log("Comparison Products:", entities.comparison_products);

const products = await Promise.all(
  entities.comparison_products.map(async (name: string) => {

    const product = await resolveProduct(name, lastProducts);

    console.log("Searching:", name);
    console.log(
      "Found:",
      product?.["Product Name"] ??
      product?.name ??
      null
    );

    return product;
  })
);

console.log("Resolved Products:", products.length);

    return products.filter(Boolean);
  }

  // Compare by product numbers
  if (entities.comparison_numbers) {

    return entities.comparison_numbers
      .map((num: number) => lastProducts[num - 1])
      .filter(Boolean);
  }

  return [];
}
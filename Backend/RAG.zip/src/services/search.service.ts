import { aiService } from "./ai.service";
import { qdrant } from "../config/qdrant";

const COLLECTION_NAME = process.env.QDRANT_COLLECTION_NAME!;

export interface SearchProduct {
  score: number;
  payload: Record<string, any>;
}

export class SearchService {

  async search(
    query: string,
    limit: number = 20
  ): Promise<SearchProduct[]> {

    try {

      console.log("Search Query:", query);

const queryVector = await aiService.embed(query);

console.log("Vector length:", queryVector.length);

const result = await qdrant.query(COLLECTION_NAME, {
  query: queryVector,
  limit,
  with_payload: true,
});

console.log("Qdrant returned:", result.points.length);

      return result.points
        .filter(point => point.payload)
        .map(point => ({
          score: point.score,
          payload: point.payload as Record<string, any>,
        }));

    } catch (error) {

      console.error("Product Search Error");
      console.error(error);

      return [];

    }
  }

}

export const searchService = new SearchService();
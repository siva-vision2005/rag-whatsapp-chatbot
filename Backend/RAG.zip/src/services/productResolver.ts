import { getProducts } from "./googleSheets.service";

export async function resolveProduct(
  reference: string | number,
  lastProducts: Record<string, any>[]
): Promise<Record<string, any> | null> {

  // ----------------------------
  // Search by product number
  // ----------------------------
  if (typeof reference === "number") {

    if (
      reference >= 1 &&
      reference <= lastProducts.length
    ) {
      return lastProducts[reference - 1];
    }

    return null;
  }

  // ----------------------------
  // Search in lastProducts
  // ----------------------------
  const search = reference.toLowerCase().trim();

  const recentProduct = lastProducts.find((product) => {

    const name =
      (
        product["Product Name"] ??
        product.name ??
        ""
      ).toLowerCase();

    return name.includes(search);

  });

  if (recentProduct) {
    return recentProduct;
  }

  // ----------------------------
  // Search full catalog
  // ----------------------------
  const products = await getProducts();

  const catalogProduct = products.find((product) => {

    const name =
      (
        product["Product Name"] ??
        product.name ??
        ""
      ).toLowerCase();

    return name.includes(search);

  });

  return catalogProduct ?? null;

}
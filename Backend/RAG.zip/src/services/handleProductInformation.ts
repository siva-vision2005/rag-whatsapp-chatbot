import { resolveProduct } from "./productResolver";
import { formatProductInformation } from "../formatter/productInformationFormatter";

export async function handleProductInformation(
  reference: string | number,
  lastProducts: Record<string, any>[]
): Promise<string> {

  const product = await resolveProduct(reference, lastProducts);

  if (!product) {
    return "Sorry, I couldn't find that product.";
  }

  return formatProductInformation(product);
}
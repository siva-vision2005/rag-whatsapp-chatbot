import { cleanMarkdown } from "./markdownFormatter";

export function formatComparisonResponse(
  title: string,
  comparison: string
): string {

  const formattedComparison = cleanMarkdown(comparison);

  return [
    "🆚 " + title,
    "",
    "════════════════════════════",
    "",
    formattedComparison,
    "",
    "════════════════════════════",
    "",
    "💬 Need more help?",
    "• Compare other products",
    "• Ask another question",
    "• Show similar products"
  ].join("\n");

}
import {
  conversationManager,
  ConversationManagerResult,
  ConversationIntent,
} from "../ai/conversationManager";
import { decideSearch } from "./searchDecision";
import { handleGeneralKnowledge } from "../handlers/generalKnowledge.handler";
import { handleProductComparison } from "../handlers/productComparison.handler";
import { handleProductSearch } from "../handlers/productSearch.handler";
import { updateConversationFields } from "./stateUpdater";
import { knowledgeIndexer } from "../knowledge/knowledgeIndexer";
import { shouldStartNewSearch } from "./searchSession";
import { ChatResponse } from "../types/chatResponse";
import { handleProductAction } from "../handlers/productAction.handler";
import { handleProductInformation } from "../services/handleProductInformation";
import {
  addMessage,
  getConversation,
  clearConversation,
} from "../memory/conversationMemory";

import {
  getConversationState,
  updateConversationState,
  updateConversationStatus,
  updateLastProducts,
  clearConversationState,
} from "./conversationState"; 

import { validateConversationFields } from "./conversationValidator";

import { getCatalogMetadata } from "../catalog/catalog.service";

export async function handleConversation(
  userId: string,
  message: string
): Promise<ChatResponse> {

  // Save customer message
  addMessage(userId, message);

  // ---------------------------------------
  // Local Knowledge (No AI)
  // ---------------------------------------

  const knowledge = knowledgeIndexer(message);

  switch (knowledge.intent) {

    case "greeting":
    case "thanks":
      return {
  type: "text",
  message: knowledge.response!
};

    case "goodbye":
      clearConversation(userId);
      clearConversationState(userId);
      return {
  type: "text",
  message: knowledge.response!
};

    case "continue":
      break;
  }

  // ---------------------------------------
  // Conversation Manager
  // ---------------------------------------

  const conversationHistory = getConversation(userId);

  const currentConversation = getConversationState(userId);

  const currentState = currentConversation.fields;

  const catalogMetadata = getCatalogMetadata();

 const conversationResult: ConversationManagerResult =
  await conversationManager(
    message,
    conversationHistory,
    catalogMetadata,
    currentState
  );
  console.log("\n========== AI INTENT ==========");
console.log("Intent:", conversationResult.intent);
console.log("Entities:");
console.log(conversationResult.entities);
console.log("===============================\n");

  // ---------------------------------------
  // Intent Routing
  // ---------------------------------------

  switch (conversationResult.intent) {

    case "general_knowledge":
      return {
  type: "text",
  message: await handleGeneralKnowledge(message)
};
    

    case "product_comparison": {

  const currentConversation =
    getConversationState(userId);
    console.log("\n========== COMPARISON ==========");
console.log(
  "Products in memory:",
  currentConversation.lastProducts.length
);

console.log(
  currentConversation.lastProducts.map(
    (p) =>
      p["Product Name"] ??
      p.name ??
      p.title
  )
);

console.log("================================\n");

 return {
  type: "text",
  message: await handleProductComparison(
    conversationResult.entities,
    currentConversation.lastProducts
  )
};

}
case "product_information": {

  const currentConversation =
    getConversationState(userId);

  // Conversation manager should provide one of these
  const reference =
    conversationResult.entities.product_name ??
    conversationResult.entities.model ??
    conversationResult.entities.product_number;

  return {
    type: "text",
    message: await handleProductInformation(
      reference,
      currentConversation.lastProducts
    )
  };

}
case "product_action": {

  const currentConversation =
    getConversationState(userId);

  const response = await handleProductAction(
    conversationResult.entities,
    currentConversation.lastProducts
  );

  if (response.type === "image") {
    return {
      type: "product_image",
      product: response.product
    };
  }

  return {
    type: "text",
    message: response.message ?? ""
  };

}
    case "product_discovery":
    break;
    default:
      break;
  }

  // ---------------------------------------
  // Validate AI Output
  // ---------------------------------------

  const validation = validateConversationFields(
  conversationResult.entities,
  catalogMetadata
);
//---------------------------------------
// New Search Detection
//---------------------------------------

if (
  shouldStartNewSearch(
    message,
    currentConversation.fields,
    validation.extractedFields
)
) {

  console.log("\n========== NEW SEARCH ==========");
  console.log("Clearing previous search state");
  console.log("================================\n");

  clearConversationState(userId);

}

  if (validation.removedFields.length > 0) {

    console.log("\n========== VALIDATOR ==========");
    console.log("Removed Fields:");
    console.log(validation.removedFields);
    console.log("===============================\n");

  }

  if (Object.keys(validation.extractedFields).length > 0) {
        //---------------------------------------
// Fresh Search Detection
//---------------------------------------

  const latestState = getConversationState(userId);

const updatedFields = updateConversationFields(
    latestState.fields,
    validation.extractedFields
);

  updateConversationState(
    userId,
    updatedFields
  );

  updateConversationStatus(
    userId,
    "COLLECTING_INFO"
  );

}

// ---------------------------------------
// Decide Whether to Search
// ---------------------------------------

const latestConversation = getConversationState(userId);

const decision = decideSearch(
  latestConversation.fields
);

console.log("\n========== SEARCH DECISION ==========");
console.log(decision);
console.log("=====================================\n");

if (!decision.shouldSearch) return {
  type: "text",
  message: "Could you tell me a little more about what you're looking for?"
};

  // ---------------------------------------
  // Product Search
  // ---------------------------------------

  updateConversationStatus(
    userId,
    "SEARCHING"
  );

  const searchResult =
  await handleProductSearch(
    message,
    latestConversation.fields
  );
  console.log("Top Product:");
console.log(searchResult.products[0]);

// Save the displayed products for future comparison
updateLastProducts(
  userId,
  searchResult.products
);
console.log("\n========== SAVED LAST PRODUCTS ==========");
console.log(
  getConversationState(userId).lastProducts.length
);
console.log(
  getConversationState(userId).lastProducts.map(
    (p) =>
      p["Product Name"] ??
      p.name ??
      p.title
  )
);
console.log("=========================================\n");

updateConversationStatus(
  userId,
  "SEARCH_COMPLETED"
);

return {
  type: "products",
  message: searchResult.reply,
  products: searchResult.products.map(product => ({
    payload: product
  })),
  bestProduct: searchResult.products[0]
};
}
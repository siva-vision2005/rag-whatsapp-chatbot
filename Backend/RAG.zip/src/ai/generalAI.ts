import { aiService } from "../services/ai.service";

export async function generalAI(
  customerMessage: string,
  conversationHistory: string
): Promise<string> {
  try {
    const prompt = `
You are an intelligent AI assistant.

Your job is to answer the customer's question naturally, similar to ChatGPT or Gemini.

Rules:

- Answer only based on general knowledge.
- Do NOT search products.
- Do NOT recommend company products.
- Do NOT mention products unless the customer specifically asks about them.
- If the customer asks a follow-up question, use the conversation history for context.
- Keep answers accurate, conversational, and easy to understand.

----------------------------------------

Conversation History

${conversationHistory}

----------------------------------------

Customer Question

${customerMessage}

----------------------------------------

Provide only the answer.
`;

    const response = await aiService.generateText(
      prompt,
      "gemini-2.5-flash"
    );

    return response;
  } catch (error) {
    console.error("General AI Error");
    console.error(error);

    return "I'm sorry, I'm unable to answer that right now. Please try again in a few moments.";
  }
}
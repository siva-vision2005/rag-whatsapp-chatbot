export type Tool =
  | "catalog_search"
  | "catalog_filter"
  | "memory"
  | "comparison"
  | "recommendation"
  | "general_knowledge"
  | "clarification"
  | "response_generator";
  export type Intent =
  | "greeting"
  | "product_search"
  | "product_comparison"
  | "product_details"
  | "recommendation"
  | "general_knowledge"
  | "help"
  | "unknown";

export interface PlannerEntities {
  brand?: string;
  category?: string;
  productName?: string;
  budget?: number;

  processor?: string;
  ram?: string;
  storage?: string;
  gpu?: string;

  purpose?: string;

  compareProducts?: string[];

  quantity?: number;
}

export interface PlannerPlan {
  intent: Intent;

  goal: string;

  tools: Tool[];

  entities: PlannerEntities;

  useCatalog: boolean;

  useMemory: boolean;

  useGeneralKnowledge: boolean;

  needComparison: boolean;

  needRecommendation: boolean;

  missingInformation: string[];

  confidence: number;
}
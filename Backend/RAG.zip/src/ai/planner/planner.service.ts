import { GeminiProvider } from "../../providers/GeminiProvider";
import { PLANNER_PROMPT } from "./planner.prompt";
import { PlannerPlan } from "./planner.types";

export class PlannerService {
  private provider = new GeminiProvider();

  async plan(userMessage: string): Promise<PlannerPlan> {
    const prompt = `
${PLANNER_PROMPT}

User:
${userMessage}
`;

    return this.provider.generateJson<PlannerPlan>(prompt);
  }
}
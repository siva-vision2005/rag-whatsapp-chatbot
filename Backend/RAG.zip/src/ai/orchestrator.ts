import { aiService } from "../services/ai.service";
import { buildOrchestratorPrompt } from "../prompts/orchestrator.prompt";

export interface OrchestratorResult {
  action:
    | "greeting"
    | "goodbye"
    | "thanks"
    | "general_ai"
    | "product_search"
    | "product_details"
    | "compare_products"
    | "recommend_products"
    | "company_knowledge"
    | "support"
    | "unknown";

  confidence: number;

  reason: string;
}

export async function orchestrator(
  customerMessage: string,
  conversationHistory: string
): Promise<OrchestratorResult> {

  try {

    const prompt = buildOrchestratorPrompt(
      customerMessage,
      conversationHistory
    );

    const result =
      await aiService.generateJson<OrchestratorResult>(
        prompt,
        "gemini-2.5-flash"
      );

    console.log("\n========== AI ORCHESTRATOR ==========");
    console.log(JSON.stringify(result, null, 2));
    console.log("=====================================\n");

    return result;

  } catch (error) {

    console.error("Orchestrator Error");
    console.error(error);

    return {
      action: "unknown",
      confidence: 0,
      reason: "Failed to classify request."
    };
  }
}
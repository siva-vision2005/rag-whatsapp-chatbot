import { buildConversationManagerPrompt } from "../prompts/conversationManager.prompt";
import { aiService } from "../services/ai.service";
import { PlannerService } from "../ai/planner/planner.service";

const planner = new PlannerService();

export type ConversationIntent =
  | "product_discovery"
  | "product_information"
  | "product_action"
  | "product_comparison"
  | "general_knowledge"
  | "company_information"
  | "support"
  | "greeting"
  | "feedback"
  | "complaint"
  | "unknown";

export interface ConversationManagerResult {
  intent: ConversationIntent;
  entities: Record<string, any>;
}

export async function conversationManager(
  customerMessage: string,
  conversationHistory: string,
  catalogMetadata: any,
  conversationState: Record<string, any>
): Promise<ConversationManagerResult> {
  try {
    const plan = await planner.plan(customerMessage);

console.log("\n========== Planner ==========");
console.log(JSON.stringify(plan, null, 2));
console.log("=============================\n");
    const prompt = buildConversationManagerPrompt(
      customerMessage,
      conversationHistory,
      catalogMetadata,
      conversationState
    );

    const result =
      await aiService.generateJson<ConversationManagerResult>(prompt);

    console.log("\n========== Conversation Manager ==========");
    console.log(JSON.stringify(result, null, 2));
    console.log("==========================================\n");

    return {
      intent: result.intent ?? "unknown",
      entities:
        typeof result.entities === "object" &&
        result.entities !== null
          ? result.entities
          : {},
    };
  } catch (error) {
    console.error("Conversation Manager Error");
    console.error(error);

    return {
      intent: "unknown",
      entities: {},
    };
  }
}